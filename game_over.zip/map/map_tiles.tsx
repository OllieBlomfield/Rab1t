<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="map_tiles" tilewidth="16" tileheight="16" tilecount="8" columns="4">
 <image source="map_tiles.png" width="64" height="32"/>
</tileset>
